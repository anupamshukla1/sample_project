import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
import React from 'react';
import Aboutus from './components/Aboutus';
import './components/Aboutus.css'


function App() {
  return (
    <>
      <div className="App">
        
        <Header/>
        <Aboutus/>
      </div>
    </>
  );
}

export default App;
